package ir.iranoptions.smart.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Direct-to-source market client. No intermediary server is used. */
object MarketApi {
    private const val TSETMC_OPTIONS_URL = "https://cdn.tsetmc.com/api/Instrument/GetInstrumentOptionMarketWatch/1"
    private const val IME_URL = "https://cdn.ime.co.ir/"
    private const val TIMEOUT_MS = 12_000

    suspend fun refresh(): RefreshResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val tehran = requestTsetmc()
        val ime = requestIme()
        RefreshResult(
            tehran = tehran,
            ime = ime,
            fetchedAt = now,
            fetchedAtText = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale("fa", "IR")).format(Date(now))
        )
    }

    private fun requestTsetmc(): SourceResult = try {
        val text = getText(TSETMC_OPTIONS_URL)
        val json = parseJsonObject(text)
        val items = extractContracts(json, "بورس تهران")
        if (items.isNotEmpty()) SourceResult("بورس تهران", SourceState.CONNECTED, items,
            "داده از نقطه پایانی TSETMC دریافت شد؛ زمان واقعی منبع ممکن است با زمان دریافت فرق داشته باشد.", TSETMC_OPTIONS_URL)
        else SourceResult("بورس تهران", SourceState.EMPTY, emptyList(),
            "پاسخ دریافت شد اما ساختار آن به قراردادهای قابل‌نمایش نگاشت نشد؛ ممکن است API تغییر کرده یا داده‌ای برنگردانده باشد.", TSETMC_OPTIONS_URL)
    } catch (e: Exception) {
        SourceResult("بورس تهران", SourceState.ERROR, emptyList(), explainError(e), TSETMC_OPTIONS_URL)
    }

    private fun requestIme(): SourceResult = try {
        val text = getText(IME_URL)
        val trimmed = text.trimStart()
        if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) {
            SourceResult("بورس کالای ایران", SourceState.NEEDS_API, emptyList(),
                "این نشانی پاسخ JSON قابل‌مصرف برای داده بازار نداد (احتمالاً صفحه وب/میزبان محتواست). برای دریافت خودکار قیمت‌ها، نشانی API عمومی مستندشده یا توکن مجاز IME لازم است.", IME_URL)
        } else {
            val json = parseJsonObject(text)
            val items = extractContracts(json, "بورس کالا")
            if (items.isNotEmpty()) SourceResult("بورس کالای ایران", SourceState.CONNECTED, items,
                "پاسخ JSON دریافت شد؛ تازگی داده باید از زمان درج‌شده در منبع تأیید شود.", IME_URL)
            else SourceResult("بورس کالای ایران", SourceState.EMPTY, emptyList(),
                "پاسخ JSON دریافت شد اما قراردادهای اختیار معامله از آن قابل استخراج نبودند.", IME_URL)
        }
    } catch (e: Exception) {
        SourceResult("بورس کالای ایران", SourceState.ERROR, emptyList(), explainError(e), IME_URL)
    }


    private fun parseJsonObject(text: String): JSONObject {
        val trimmed = text.trim()
        return when {
            trimmed.startsWith("{") -> JSONObject(trimmed)
            trimmed.startsWith("[") -> JSONObject().put("items", JSONArray(trimmed))
            else -> throw IllegalStateException("پاسخ منبع JSON نیست")
        }
    }

    private fun getText(address: String): String {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36")
            setRequestProperty("Accept", "application/json,text/plain,text/html,*/*")
            setRequestProperty("Cache-Control", "no-cache")
            instanceFollowRedirects = true
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("HTTP $code${if (body.isNotBlank()) " — ${body.take(120)}" else ""}")
            if (body.isBlank()) throw IllegalStateException("پاسخ خالی از منبع")
            return body
        } finally { connection.disconnect() }
    }

    private fun explainError(e: Exception): String {
        val message = e.message.orEmpty()
        return when {
            message.contains("403") || message.contains("303") -> "دسترسی رد شد (HTTP). ممکن است منبع دسترسی خارج از ایران را محدود کرده باشد. جزئیات: $message"
            message.contains("Unable to resolve host", true) -> "اتصال اینترنت یا DNS در دسترس نیست."
            message.contains("timed out", true) || message.contains("timeout", true) -> "پاسخ منبع در مهلت مقرر نرسید؛ بعداً دوباره تلاش کنید."
            else -> "دریافت داده ناموفق بود: ${message.take(220)}"
        }
    }

    private fun extractContracts(root: JSONObject, market: String): List<ContractItem> {
        val found = mutableListOf<JSONObject>()
        collectObjects(root, found, 0)
        val seen = mutableSetOf<String>()
        return found.mapNotNull { obj ->
            val symbol = firstString(obj, listOf("lVal18AFC", "lVal30", "symbol", "Symbol", "instrumentName", "InstrumentName", "contractName", "ContractName", "namad", "نام نماد"))
                ?: return@mapNotNull null
            val last = firstNumber(obj, listOf("pDrCotVal", "pl", "lastPrice", "LastPrice", "last", "price", "Price", "pClosing", "closingPrice", "ClosingPrice"))
            val strike = firstNumber(obj, listOf("strikePrice", "StrikePrice", "qeymateEmal", "QeymateEmal", "xNivIn", "exercisePrice", "ExercisePrice"))
            val bid = firstNumber(obj, listOf("pMeDem", "bid", "Bid", "bestBid", "BestBid", "bidPrice", "BidPrice"))
            val ask = firstNumber(obj, listOf("pMeOf", "ask", "Ask", "bestAsk", "BestAsk", "askPrice", "AskPrice"))
            val volume = firstNumber(obj, listOf("qTotTran5J", "volume", "Volume", "tradeVolume", "TradeVolume"))?.toLong()
            if (last == null && bid == null && ask == null && strike == null) return@mapNotNull null
            val key = "$market|$symbol|${strike ?: ""}"
            if (!seen.add(key)) return@mapNotNull null
            val typeText = firstString(obj, listOf("optionType", "OptionType", "type", "Type", "callPut", "CallPut", "noe", "نوع" )).orEmpty()
            val type = when {
                typeText.contains("put", true) || typeText.contains("فروش") || typeText.contains("پ") -> "اختیار فروش"
                typeText.contains("call", true) || typeText.contains("خرید") || typeText.contains("ک") -> "اختیار خرید"
                else -> "نوع قرارداد از پاسخ منبع مشخص نشد"
            }
            val expiry = firstString(obj, listOf("expiry", "Expiry", "expiryDate", "ExpiryDate", "tarixSarresid", "TarixSarresid", "dEven", "DEven"))
            ContractItem(symbol, market, type, strike, last, bid, ask, volume, expiry)
        }.take(250)
    }

    private fun collectObjects(value: Any?, output: MutableList<JSONObject>, depth: Int) {
        if (depth > 8) return
        when (value) {
            is JSONObject -> {
                output.add(value)
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    collectObjects(value.opt(key), output, depth + 1)
                }
            }
            is JSONArray -> for (i in 0 until minOf(value.length(), 1500)) collectObjects(value.opt(i), output, depth + 1)
        }
    }

    private fun firstString(obj: JSONObject, keys: List<String>): String? {
        for (key in keys) {
            val value = obj.opt(key)
            if (value != null && value != JSONObject.NULL && value !is JSONObject && value !is JSONArray) {
                val text = value.toString().trim()
                if (text.isNotEmpty() && text != "0" && text != "null") return text
            }
        }
        return null
    }

    private fun firstNumber(obj: JSONObject, keys: List<String>): Double? {
        for (key in keys) {
            val value = obj.opt(key)
            val candidate = when (value) {
                is Number -> value.toDouble()
                is String -> value.replace(",", "").trim().toDoubleOrNull()
                is JSONObject -> {
                    val nested = value.opt("value")
                    when (nested) { is Number -> nested.toDouble(); is String -> nested.toDoubleOrNull(); else -> null }
                }
                else -> null
            }
            if (candidate != null && candidate.isFinite() && candidate >= 0) return candidate
        }
        return null
    }
}

data class ContractItem(
    val symbol: String,
    val market: String,
    val type: String,
    val strike: Double?,
    val last: Double?,
    val bid: Double?,
    val ask: Double?,
    val volume: Long?,
    val expiry: String?
)

enum class SourceState { CONNECTED, EMPTY, NEEDS_API, ERROR }

data class SourceResult(
    val name: String,
    val state: SourceState,
    val contracts: List<ContractItem>,
    val message: String,
    val url: String
)

data class RefreshResult(
    val tehran: SourceResult,
    val ime: SourceResult,
    val fetchedAt: Long,
    val fetchedAtText: String
) {
    val contracts: List<ContractItem> get() = tehran.contracts + ime.contracts
}
