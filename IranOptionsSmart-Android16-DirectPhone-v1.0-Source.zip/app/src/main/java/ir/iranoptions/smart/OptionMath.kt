package ir.iranoptions.smart

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.math.PI
import kotlin.math.pow

/** Results are theoretical estimates, not market quotes or trade recommendations. */
data class OptionGreeks(
    val theoreticalPrice: Double,
    val delta: Double,
    val gamma: Double,
    val thetaPerDay: Double,
    val vegaPerOneVolPoint: Double
)

object OptionMath {
    /** Standard Black–Scholes estimate for European options. Inputs: volatility and rate as decimals. */
    fun blackScholes(
        spot: Double,
        strike: Double,
        daysToExpiry: Double,
        annualVolatility: Double,
        annualRiskFreeRate: Double,
        isCall: Boolean
    ): OptionGreeks? {
        if (spot <= 0 || strike <= 0 || daysToExpiry <= 0 || annualVolatility <= 0) return null
        val t = daysToExpiry / 365.0
        val sigma = annualVolatility
        val r = annualRiskFreeRate
        val sqrtT = sqrt(t)
        val d1 = (ln(spot / strike) + (r + sigma * sigma / 2.0) * t) / (sigma * sqrtT)
        val d2 = d1 - sigma * sqrtT
        val nd1 = cdf(d1)
        val nd2 = cdf(d2)
        val nMinusD1 = cdf(-d1)
        val nMinusD2 = cdf(-d2)
        val pdfD1 = exp(-d1 * d1 / 2.0) / sqrt(2.0 * PI)
        val discountedStrike = strike * exp(-r * t)
        val price = if (isCall) spot * nd1 - discountedStrike * nd2
                    else discountedStrike * nMinusD2 - spot * nMinusD1
        val delta = if (isCall) nd1 else nd1 - 1.0
        val gamma = pdfD1 / (spot * sigma * sqrtT)
        val thetaYear = if (isCall) {
            -(spot * pdfD1 * sigma) / (2.0 * sqrtT) - r * discountedStrike * nd2
        } else {
            -(spot * pdfD1 * sigma) / (2.0 * sqrtT) + r * discountedStrike * nMinusD2
        }
        val vegaPerVolUnit = spot * pdfD1 * sqrtT
        return OptionGreeks(
            theoreticalPrice = price,
            delta = delta,
            gamma = gamma,
            thetaPerDay = thetaYear / 365.0,
            vegaPerOneVolPoint = vegaPerVolUnit / 100.0
        )
    }

    // Abramowitz–Stegun approximation of the standard normal CDF.
    private fun cdf(x: Double): Double {
        val ax = kotlin.math.abs(x)
        val t = 1.0 / (1.0 + 0.2316419 * ax)
        val density = exp(-ax * ax / 2.0) / sqrt(2.0 * PI)
        val p = 1.0 - density * (0.319381530 * t - 0.356563782 * t.pow(2) +
            1.781477937 * t.pow(3) - 1.821255978 * t.pow(4) + 1.330274429 * t.pow(5))
        return if (x >= 0) p else 1.0 - p
    }
}
