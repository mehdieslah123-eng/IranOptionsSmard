package ir.iranoptions.smart

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.iranoptions.smart.data.ContractItem
import ir.iranoptions.smart.data.MarketApi
import ir.iranoptions.smart.data.RefreshResult
import ir.iranoptions.smart.data.SourceResult
import ir.iranoptions.smart.data.SourceState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Panel2 = Color(0xFF1D2940)
private val Accent = Color(0xFF52D6A2)
private val Red = Color(0xFFFF6B78)
private val Amber = Color(0xFFFFD27D)
private val Muted = Color(0xFF9AA8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OptionsApp() }
    }
}

@Composable
fun OptionsApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var refreshResult by remember { mutableStateOf<RefreshResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var lastError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun refresh(manual: Boolean = false) {
        if (loading) return
        scope.launch {
            loading = true
            try {
                refreshResult = MarketApi.refresh()
                lastError = null
            } catch (e: Exception) {
                lastError = e.message ?: "خطای ناشناخته"
            } finally { loading = false }
        }
    }

    LaunchedEffect(Unit) {
        refresh()
        while (true) {
            delay(60_000)
            if (!loading) refresh()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, secondary = Color(0xFF8AA7FF),
        onBackground = Color.White, onSurface = Color.White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("داشبورد") })
                        NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.ShowChart, null) }, label = { Text("قراردادها") })
                        NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("ماشین‌حساب") })
                        NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("گزارش") })
                    }
                }
            ) { padding ->
                when (selectedTab) {
                    0 -> Dashboard(Modifier.padding(padding), refreshResult, loading, lastError, onRefresh = { refresh(true) }, onOpenCalculator = { selectedTab = 2 })
                    1 -> ContractsScreen(Modifier.padding(padding), refreshResult, loading, onRefresh = { refresh(true) })
                    2 -> Calculator(Modifier.padding(padding))
                    else -> Reports(Modifier.padding(padding), refreshResult, onRefresh = { refresh(true) }, loading = loading)
                }
            }
        }
    }
}

@Composable
fun Dashboard(
    modifier: Modifier,
    result: RefreshResult?,
    loading: Boolean,
    lastError: String?,
    onRefresh: () -> Unit,
    onOpenCalculator: () -> Unit
) {
    val contracts = result?.contracts.orEmpty()
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("آپشن هوشمند ایرانیان", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("تحلیل اختیار معامله · اتصال مستقیم از گوشی", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = onRefresh, enabled = !loading) { Icon(Icons.Default.Refresh, contentDescription = "به‌روزرسانی", tint = Accent) }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("وضعیت دریافت اطلاعات", color = Muted, fontSize = 12.sp)
                            Text(if (loading) "در حال دریافت از منابع بازار…" else result?.fetchedAtText?.let { "آخرین تلاش: $it" } ?: "هنوز دریافت انجام نشده", color = if (loading) Amber else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                        if (loading) CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = Accent)
                    }
                    Text("قراردادهای دریافتی: ${toFa(contracts.size.toString())}", color = Accent, fontWeight = FontWeight.Bold)
                    if (lastError != null) Text(lastError, color = Red, fontSize = 12.sp)
                    Text("این برنامه مستقیماً از گوشی درخواست اینترنت می‌فرستد؛ سرور واسط ندارد. اگر منبع دسترسی را محدود کند، داده زنده در دسترس نخواهد بود.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item { SourceStatusCard(result?.tehran, onRefresh) }
        item { SourceStatusCard(result?.ime, onRefresh) }
        item { Button(onClick = onOpenCalculator, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(14.dp)) { Text("محاسبه سود و زیان قرارداد", color = Bg, fontWeight = FontWeight.Bold) } }
        item { Text("آخرین قراردادهای دریافت‌شده", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (contracts.isEmpty()) {
            item { EmptyState("هنوز قراردادی از منبع قابل‌خواندن دریافت نشده است.", "وضعیت اتصال هر منبع را بالا بررسی کنید؛ هیچ داده فرضی به‌عنوان قیمت بازار نمایش داده نمی‌شود.") }
        } else {
            items(contracts.take(5)) { ContractCard(it) }
        }
        item { Text("سیگنال خریدوفروش تا زمانی که داده و مشخصات قرارداد تأیید نشده باشد تولید نمی‌شود.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
    }
}

@Composable
fun ContractsScreen(modifier: Modifier, result: RefreshResult?, loading: Boolean, onRefresh: () -> Unit) {
    var filter by remember { mutableIntStateOf(0) }
    val all = result?.contracts.orEmpty()
    val shown = when (filter) { 1 -> all.filter { it.market.contains("تهران") }; 2 -> all.filter { it.market.contains("کالا") }; else -> all }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("قراردادهای بازار", fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh, enabled = !loading) { Icon(Icons.Default.Refresh, null, tint = Accent) }
            }
        }
        item { Text("فقط داده‌ای نمایش داده می‌شود که از منبع دریافت و از پاسخ استخراج شده باشد.", color = Muted, fontSize = 12.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("همه") })
                FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("بورس تهران") })
                FilterChip(selected = filter == 2, onClick = { filter = 2 }, label = { Text("بورس کالا") })
            }
        }
        if (shown.isEmpty()) item { EmptyState("قراردادی برای نمایش موجود نیست.", "دکمه به‌روزرسانی را بزنید یا وضعیت اتصال منابع را در داشبورد ببینید.") }
        else items(shown) { ContractCard(it) }
    }
}

@Composable
fun SourceStatusCard(source: SourceResult?, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val state = source?.state
    val tint = when (state) {
        SourceState.CONNECTED -> Accent
        SourceState.EMPTY -> Amber
        SourceState.NEEDS_API -> Amber
        SourceState.ERROR -> Red
        null -> Muted
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(source?.name ?: "منبع بازار", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Surface(color = tint.copy(alpha = 0.14f), shape = RoundedCornerShape(9.dp)) {
                    Text(statusLabel(state), color = tint, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(source?.message ?: "هنوز بررسی نشده است.", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRefresh, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text("تلاش دوباره", fontSize = 11.sp) }
                OutlinedButton(onClick = { source?.url?.let { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text("بازکردن منبع", fontSize = 11.sp) }
            }
        }
    }
}

@Composable
fun ContractCard(item: ContractItem) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.symbol, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(item.market, color = Muted, fontSize = 11.sp)
                }
                Text(item.type, color = Color(0xFF8AA7FF), fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ValuePill("آخرین", item.last?.let(::fmt) ?: "—", Modifier.weight(1f))
                ValuePill("خرید", item.bid?.let(::fmt) ?: "—", Modifier.weight(1f))
                ValuePill("فروش", item.ask?.let(::fmt) ?: "—", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("قیمت اعمال: ${item.strike?.let(::fmt) ?: "نامشخص"}", color = Muted, fontSize = 11.sp)
                Text("حجم: ${item.volume?.let { toFa(it.toString()) } ?: "—"}", color = Muted, fontSize = 11.sp)
            }
            if (!item.expiry.isNullOrBlank()) Text("سررسید درج‌شده در منبع: ${item.expiry}", color = Muted, fontSize = 10.sp)
            Text("اطلاعات استخراج‌شده از پاسخ منبع؛ پیش از معامله با تابلوی رسمی تطبیق دهید.", color = Amber, fontSize = 10.sp)
        }
    }
}

@Composable
fun ValuePill(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel2, shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(9.dp)) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(toFa(value), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun EmptyState(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(description, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun Calculator(modifier: Modifier = Modifier) {
    var premium by remember { mutableStateOf("500") }
    var strike by remember { mutableStateOf("10000") }
    var expiryPrice by remember { mutableStateOf("11000") }
    var multiplier by remember { mutableStateOf("100") }
    var spot by remember { mutableStateOf("10000") }
    var days by remember { mutableStateOf("30") }
    var volatility by remember { mutableStateOf("30") }
    var rate by remember { mutableStateOf("25") }
    var isCall by remember { mutableStateOf(true) }
    val p = parseNum(premium); val k = parseNum(strike); val s = parseNum(expiryPrice); val m = parseNum(multiplier)
    val theoretical = if (parseNum(spot) != null && k != null && parseNum(days) != null && parseNum(volatility) != null && parseNum(rate) != null) OptionMath.blackScholes(parseNum(spot)!!, k, parseNum(days)!!, parseNum(volatility)!! / 100.0, parseNum(rate)!! / 100.0, isCall) else null
    val result = if (p != null && k != null && s != null && m != null && p >= 0 && k > 0 && s >= 0 && m > 0) ((if (isCall) maxOf(s - k, 0.0) else maxOf(k - s, 0.0)) - p) * m else null
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("ماشین‌حساب سود و زیان", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        item { Text("سود/زیان خریدار در سررسید؛ کارمزد، مالیات، تسویه و ضریب اختصاصی قرارداد لحاظ نشده است.", color = Muted, fontSize = 12.sp) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = isCall, onClick = { isCall = true }, label = { Text("اختیار خرید") })
                        FilterChip(selected = !isCall, onClick = { isCall = false }, label = { Text("اختیار فروش") })
                    }
                    NumberField("قیمت پرداختی هر واحد اختیار", premium) { premium = it }
                    NumberField("قیمت اعمال", strike) { strike = it }
                    NumberField("قیمت دارایی در سررسید", expiryPrice) { expiryPrice = it }
                    NumberField("ضریب / اندازه قرارداد", multiplier) { multiplier = it }
                    HorizontalDivider(color = Muted.copy(alpha = 0.25f))
                    Text("برآورد نظری و یونانی‌ها (مدل بلک–شولز)", fontWeight = FontWeight.SemiBold)
                    NumberField("قیمت فعلی دارایی پایه", spot) { spot = it }
                    NumberField("روزهای باقی‌مانده تا سررسید", days) { days = it }
                    NumberField("نوسان‌پذیری سالانه به درصد", volatility) { volatility = it }
                    NumberField("نرخ سالانه به درصد", rate) { rate = it }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("نتیجه برآوردی", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(result?.let { fmt(it) + " واحد پولی" } ?: "ورودی‌ها را بررسی کنید", color = result?.let { if (it >= 0) Accent else Red } ?: Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(if (result == null) "مقادیر مثبت و معتبر وارد کنید." else if (result >= 0) "سود خالص تقریبی پیش از هزینه‌ها" else "زیان خالص تقریبی پیش از هزینه‌ها", color = Muted, fontSize = 12.sp)
                    val breakeven = if (p != null && k != null) if (isCall) k + p else k - p else null
                    if (breakeven != null) Text("نقطه سربه‌سر تقریبی: ${fmt(breakeven)}", modifier = Modifier.padding(top = 10.dp), color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("برآورد نظری و شاخص‌های یونانی", fontWeight = FontWeight.Bold)
                    if (theoretical == null) {
                        Text("برای محاسبه، قیمت‌ها باید مثبت باشند و روز سررسید، نوسان و نرخ معتبر وارد شوند.", color = Muted, fontSize = 12.sp)
                    } else {
                        Text("قیمت نظری: ${fmt(theoretical.theoreticalPrice)}")
                        Text("Delta: ${fmt(theoretical.delta)}")
                        Text("Gamma: ${fmt(theoretical.gamma)}")
                        Text("Theta روزانه: ${fmt(theoretical.thetaPerDay)}")
                        Text("Vega به‌ازای ۱ واحد درصد نوسان: ${fmt(theoretical.vegaPerOneVolPoint)}")
                    }
                    Text("بلک–شولز یک مدل نظری اروپایی است؛ قواعد تسویه و ویژگی‌های قراردادهای ایرانی ممکن است متفاوت باشد. این خروجی سیگنال خریدوفروش نیست.", color = Amber, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun Reports(modifier: Modifier, result: RefreshResult?, onRefresh: () -> Unit, loading: Boolean) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("گزارش وضعیت بازار", fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh, enabled = !loading) { Icon(Icons.Default.Refresh, null, tint = Accent) }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("خلاصه آخرین دریافت", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("زمان تلاش: ${result?.fetchedAtText ?: "هنوز انجام نشده"}", color = Muted, fontSize = 12.sp)
                    Text("قراردادهای استخراج‌شده: ${toFa(result?.contracts?.size?.toString() ?: "0")}", color = Accent, fontWeight = FontWeight.Bold)
                    Text("بورس تهران: ${statusLabel(result?.tehran?.state)}", color = stateColor(result?.tehran?.state), fontSize = 12.sp)
                    Text("بورس کالا: ${statusLabel(result?.ime?.state)}", color = stateColor(result?.ime?.state), fontSize = 12.sp)
                    Text("این گزارش فقط وضعیت دریافت را خلاصه می‌کند؛ تا وقتی داده تاریخی و قراردادها به‌درستی اعتبارسنجی نشده‌اند، عملکرد سیگنال یا بازده فرضی نمایش داده نمی‌شود.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { Text("برای هشدار پس‌زمینه دائمی، محدودیت‌های باتری اندروید و منبع داده باید جداگانه بررسی شود. این نسخه هنگام بازبودن برنامه هر ۶۰ ثانیه تلاش به‌روزرسانی می‌کند.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { input -> onValueChange(input.filter { it.isDigit() || it == '.' || it == ',' }) }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, focusedLabelColor = Accent))
}

fun statusLabel(state: SourceState?): String = when (state) {
    SourceState.CONNECTED -> "دریافت شد"
    SourceState.EMPTY -> "بدون قرارداد قابل‌استخراج"
    SourceState.NEEDS_API -> "نیازمند API داده"
    SourceState.ERROR -> "خطا در اتصال"
    null -> "بررسی نشده"
}

fun stateColor(state: SourceState?): Color = when (state) {
    SourceState.CONNECTED -> Accent
    SourceState.EMPTY, SourceState.NEEDS_API -> Amber
    SourceState.ERROR -> Red
    null -> Muted
}

fun parseNum(value: String): Double? = value.replace(",", "").trim().toDoubleOrNull()
fun fmt(value: Double): String = String.format(Locale.US, "%,.2f", value).trimEnd('0').trimEnd('.')
fun toFa(text: String): String = text.map { if (it in '0'..'9') ('۰'.code + (it.code - '0'.code)).toChar() else it }.joinToString("")
