package ir.iranoptions.smart.data

/** Normalized contract model. Prices must include a source timestamp and must never be silently treated as live. */
data class OptionContractQuote(
    val symbol: String,
    val market: Market,
    val underlying: String,
    val optionType: OptionType,
    val strike: Double,
    val expiryEpochMillis: Long,
    val bid: Double?,
    val ask: Double?,
    val last: Double?,
    val volume: Long?,
    val openInterest: Long?,
    val contractMultiplier: Double?,
    val sourceTimestampEpochMillis: Long,
    val sourceName: String,
    val isIndicative: Boolean = false
)

enum class Market { TEHRAN, COMMODITY }
enum class OptionType { CALL, PUT }
enum class DataStatus { LIVE, DELAYED, STALE, DEMO, UNAVAILABLE }

data class MarketSnapshot<T>(
    val items: List<T>,
    val status: DataStatus,
    val fetchedAtEpochMillis: Long?,
    val message: String
)

/** Implementations must use documented/authorized endpoints; do not scrape private endpoints without permission. */
interface MarketDataProvider {
    suspend fun fetchOptionContracts(market: Market): MarketSnapshot<OptionContractQuote>
}

/** Conservative freshness label based on source timestamp; thresholds should be configurable per provider. */
fun freshness(timestamp: Long?, now: Long = System.currentTimeMillis()): DataStatus {
    if (timestamp == null || timestamp <= 0L) return DataStatus.UNAVAILABLE
    val age = now - timestamp
    return when {
        age < -60_000L -> DataStatus.UNAVAILABLE
        age <= 30_000L -> DataStatus.LIVE
        age <= 5 * 60_000L -> DataStatus.DELAYED
        else -> DataStatus.STALE
    }
}
